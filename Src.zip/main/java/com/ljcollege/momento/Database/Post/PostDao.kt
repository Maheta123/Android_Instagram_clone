package com.ljcollege.momento.Database.Post

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: Post)

    @Query("SELECT * FROM posts WHERE userId = :userId ORDER BY createdAt DESC")
    fun getPostsByUser(userId: Int): Flow<List<Post>>

    @Query("SELECT * FROM posts ORDER BY createdAt DESC")
    fun getAllPosts(): Flow<List<Post>>

    @Query("UPDATE posts SET likesCount = likesCount + 1 WHERE id = :postId")
    suspend fun incrementLikes(postId: Int)

    @Query("UPDATE posts SET likesCount = likesCount - 1 WHERE id = :postId")
    suspend fun decrementLikes(postId: Int)

    @Query("DELETE FROM posts WHERE id = :postId")
    suspend fun deletePost(postId: Int)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLike(like: Like)

    @Query("DELETE FROM likes WHERE userId = :userId AND postId = :postId")
    suspend fun deleteLike(userId: Int, postId: Int)

    @Query("SELECT COUNT(*) FROM likes WHERE postId = :postId")
    suspend fun getLikesCount(postId: Int): Int

    @Query("SELECT u.username FROM users u JOIN likes l ON u.id = l.userId WHERE l.postId = :postId LIMIT 3")
    suspend fun getUsersWhoLiked(postId: Int): List<String>

    @Query("SELECT * FROM likes WHERE userId = :userId AND postId = :postId LIMIT 1")
    suspend fun getExistingLike(userId: Int, postId: Int): Like?

    @Query("SELECT COUNT(*) FROM posts")
    suspend fun getAllPostsCount(): Int

    @Query("SELECT COUNT(*) FROM posts WHERE userId = :userId")
    suspend fun getUserPostCount(userId: Int): Int

    @Query("SELECT * FROM posts WHERE userId = :userId")
    suspend fun getPostsByUserId(userId: Int): List<Post>

    @Insert
    suspend fun insertPostprofile(post: Post)

    @Update
    suspend fun updatePost(post: Post)

    @Query("SELECT * FROM posts WHERE id = :postId")
    suspend fun getPostById(postId: Int): Post?

    @Update
    suspend fun update(post: Post)

    @Delete
    suspend fun delete(post: Post)
}