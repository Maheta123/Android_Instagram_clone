package com.ljcollege.momento.Database.Post

import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.Model.Post as UiPost
import com.ljcollege.momento.R
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import android.util.Log

class PostRepository(private val postDao: PostDao, private val userRepository: UserRepository) {

    suspend fun insertPost(post: Post) {
        try {
            postDao.insertPost(post)
        } catch (e: Exception) {
            Log.e("PostRepository", "Error inserting post: ${e.message}")
            throw e
        }
    }

    fun getAllPosts(): Flow<List<UiPost>> {
        return postDao.getAllPosts().map { posts ->
            posts.map { post ->
                post.toUiModel()
            }
        }
    }

    fun getPostsByUser(userId: Int): Flow<List<UiPost>> {
        return postDao.getPostsByUser(userId).map { posts ->
            posts.map { post ->
                post.toUiModel()
            }
        }
    }

    suspend fun incrementLikes(postId: Int) {
        try {
            postDao.incrementLikes(postId)
        } catch (e: Exception) {
            Log.e("PostRepository", "Error incrementing likes for post $postId: ${e.message}")
            throw e
        }
    }

    suspend fun decrementLikes(postId: Int) {
        try {
            postDao.decrementLikes(postId)
        } catch (e: Exception) {
            Log.e("PostRepository", "Error decrementing likes for post $postId: ${e.message}")
            throw e
        }
    }

    suspend fun deletePost(postId: Int) {
        try {
            postDao.deletePost(postId)
        } catch (e: Exception) {
            Log.e("PostRepository", "Error deleting post $postId: ${e.message}")
            throw e
        }
    }

    suspend fun likePost(userId: Int, postId: Int): Boolean {
        try {
            val existingLike = postDao.getExistingLike(userId, postId)
            if (existingLike != null) return false
            val like = Like(userId = userId, postId = postId)
            postDao.insertLike(like)
            incrementLikes(postId)
            return true
        } catch (e: Exception) {
            Log.e("PostRepository", "Error liking post $postId for user $userId: ${e.message}")
            return false
        }
    }

    suspend fun unlikePost(userId: Int, postId: Int): Boolean {
        try {
            val existingLike = postDao.getExistingLike(userId, postId)
            if (existingLike == null) return false
            postDao.deleteLike(userId, postId)
            decrementLikes(postId)
            return true
        } catch (e: Exception) {
            Log.e("PostRepository", "Error unliking post $postId for user $userId: ${e.message}")
            return false
        }
    }

    suspend fun isPostLikedByUser(userId: Int, postId: Int): Boolean {
        return try {
            postDao.getExistingLike(userId, postId) != null
        } catch (e: Exception) {
            Log.e("PostRepository", "Error checking like status for post $postId by user $userId: ${e.message}")
            false
        }
    }

    suspend fun getLikesCount(postId: Int): Int {
        try {
            return postDao.getLikesCount(postId)
        } catch (e: Exception) {
            Log.e("PostRepository", "Error getting likes count for post $postId: ${e.message}")
            return 0
        }
    }

    suspend fun getUsersWhoLiked(postId: Int): List<String> {
        try {
            return postDao.getUsersWhoLiked(postId)
        } catch (e: Exception) {
            Log.e("PostRepository", "Error getting users who liked post $postId: ${e.message}")
            return emptyList()
        }
    }

    suspend fun getUsernameById(userId: Int): String {
        return userRepository.getUsernameById(userId) ?: "Unknown"
    }

    private suspend fun Post.toUiModel(): UiPost {
        try {
            val username = userRepository.getUsernameById(userId) ?: "Unknown"
            val isLiked = isPostLikedByUser(userId, id)
            return UiPost(
                id = id,
                userId = userId,
                userAvatarRes = R.drawable.ic_user_placeholder,
                username = username,
                location = location ?: "",
                mediaUrl = mediaUrl,
                likesCount = likesCount,
                caption = caption ?: "",
                postedAgo = formatTimeAgo(createdAt), // Assuming createdAt exists in DB Post entity
                isLikedByCurrentUser = isLiked
            )
        } catch (e: Exception) {
            Log.e("PostRepository", "Error mapping post to UI model: ${e.message}")
            return UiPost(
                id = id,
                userId = userId,
                userAvatarRes = R.drawable.ic_user_placeholder,
                username = "Unknown",
                location = "",
                mediaUrl = mediaUrl,
                likesCount = 0,
                caption = "",
                postedAgo = "Unknown",
                isLikedByCurrentUser = false
            )
        }
    }

    private fun formatTimeAgo(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        val minutes = diff / (1000 * 60)
        return when {
            minutes < 1 -> "Just now"
            minutes < 60 -> "$minutes minutes ago"
            minutes < 1440 -> "${minutes / 60} hours ago"
            else -> "${minutes / 1440} days ago"
        }
    }
}