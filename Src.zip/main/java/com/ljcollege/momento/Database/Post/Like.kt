package com.ljcollege.momento.Database.Post

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "likes", primaryKeys = ["userId", "postId"])
data class Like(
    val userId: Int,
    val postId: Int,
    val createdAt: Long = System.currentTimeMillis()
)