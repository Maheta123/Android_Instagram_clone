package com.ljcollege.momento.Database.Post

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class Post(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val mediaUrl: String,
    val caption: String?,
    var likesCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val location: String?
)