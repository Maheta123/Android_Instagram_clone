package com.ljcollege.momento.Database

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.ljcollege.momento.Database.Post.Like
import com.ljcollege.momento.Database.Post.Post
import com.ljcollege.momento.Database.Post.PostDao
import com.ljcollege.momento.Database.Story.Story
import com.ljcollege.momento.Database.Story.StoryDao
import com.ljcollege.momento.Database.User.User
import com.ljcollege.momento.Database.User.UserDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [User::class, Story::class, Post::class, Like::class ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun storyDao(): StoryDao
    abstract fun postDao(): PostDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Handle users table migration
                migrateUsersTable(database)

                // Handle follows table migration (check if the table exists)
                migrateFollowsTable(database)
            }

            private fun migrateUsersTable(database: SupportSQLiteDatabase) {
                try {
                    database.execSQL("""
                        CREATE TABLE users_new (
                            id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                            name TEXT NOT NULL,
                            username TEXT NOT NULL,
                            email TEXT NOT NULL,
                            password TEXT NOT NULL,
                            profilePic TEXT,
                            bio TEXT,
                            createdAt INTEGER NOT NULL
                        )
                    """)
                    database.execSQL("""
                        INSERT INTO users_new (id, name, username, email, password, profilePic, bio, createdAt)
                        SELECT id, COALESCE(name, '') AS name, username, COALESCE(email, '') AS email, COALESCE(password, '') AS password, profilePic AS profilePic, bio, createdAt
                        FROM users
                    """)
                    database.execSQL("DROP TABLE users")
                    database.execSQL("ALTER TABLE users_new RENAME TO users")
                    database.execSQL("CREATE UNIQUE INDEX index_users_username ON users(username)")
                } catch (e: Exception) {
                    Log.e("Migration", "Error migrating users table: ${e.message}")
                }
            }

            private fun migrateFollowsTable(database: SupportSQLiteDatabase) {
                // Check if 'follows' table exists
                val cursor = database.query("SELECT name FROM sqlite_master WHERE type='table' AND name='follows'")
                if (cursor.count > 0) {
                    try {
                        // If follows table exists, ensure it has the correct schema
                        database.execSQL("""
                            CREATE TABLE follows_new (
                                followerId TEXT NOT NULL,
                                followingId TEXT NOT NULL,
                                PRIMARY KEY (followerId, followingId)
                            )
                        """)
                        database.execSQL("""
                            INSERT INTO follows_new (followerId, followingId)
                            SELECT followerId, followingId
                            FROM follows
                        """)
                        database.execSQL("DROP TABLE follows")
                        database.execSQL("ALTER TABLE follows_new RENAME TO follows")
                    } catch (e: Exception) {
                        Log.e("Migration", "Error migrating follows table: ${e.message}")
                    }
                } else {
                    Log.w("Migration", "The 'follows' table does not exist. Creating a new one.")
                    // Create the follows table if it doesn't exist
                    try {
                        database.execSQL("""
                            CREATE TABLE follows (
                                followerId TEXT NOT NULL,
                                followingId TEXT NOT NULL,
                                PRIMARY KEY (followerId, followingId)
                            )
                        """)
                    } catch (e: Exception) {
                        Log.e("Migration", "Error creating follows table: ${e.message}")
                    }
                }
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "Momento_DataBase"
                )
                    .addMigrations(MIGRATION_3_4)
                    .fallbackToDestructiveMigration() // Remove in production
                    .addCallback(object : RoomDatabase.Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            Log.d("AppDatabase", "Database created, inserting dummy data")
                            val dbInstance = INSTANCE
                            if (dbInstance != null) {
                                CoroutineScope(Dispatchers.IO).launch {
                                    try {
                                        DummyDataInitializer.populateDummyData(
                                            dbInstance.userDao(),
                                            dbInstance.storyDao(),
                                            dbInstance.postDao()
                                        )
                                        Log.d("AppDatabase", "Dummy data insertion completed")
                                    } catch (e: Exception) {
                                        Log.e("AppDatabase", "Error inserting dummy data: ${e.message}")
                                    }
                                }
                            }
                        }

                        override fun onOpen(db: SupportSQLiteDatabase) {
                            super.onOpen(db)
                            Log.d("AppDatabase", "Database opened")
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
