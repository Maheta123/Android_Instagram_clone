package com.ljcollege.momento.Database.Story

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stories")
data class Story(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val userId: Int,
    val mediaUrl: String,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = createdAt + 24 * 60 * 60 * 1000 // 24 hours later
)