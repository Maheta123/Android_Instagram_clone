package com.ljcollege.momento.Database.Story

import kotlinx.coroutines.flow.Flow

class StoryRepository(private val storyDao: StoryDao) {

    suspend fun insertStory(story: Story) {
        storyDao.insertStory(story)
    }

    fun getStoriesByUser(userId: Int): Flow<List<Story>> {
        return storyDao.getStoriesByUser(userId)
    }

    fun getActiveStoriesByUser(userId: Int): Flow<List<Story>> {
        return storyDao.getActiveStoriesByUser(userId)
    }

    suspend fun cleanExpiredStories() {
        storyDao.deleteExpiredStories()
    }

    // Testing
    fun getAllActiveStoriesByUser(userId: Int): Flow<List<Story>> {
        return storyDao.getAllActiveStoriesByUser(userId)
    }
}