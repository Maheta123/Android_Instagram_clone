package com.ljcollege.momento.Database.Story

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface StoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: Story)

    @Query("SELECT * FROM stories WHERE userId = :userId ORDER BY createdAt DESC")
    fun getStoriesByUser(userId: Int): Flow<List<Story>>

    @Query("SELECT * FROM stories WHERE userId = :userId AND expiresAt > :currentTime ORDER BY createdAt DESC")
    fun getActiveStoriesByUser(userId: Int, currentTime: Long = System.currentTimeMillis()): Flow<List<Story>>

    @Query("DELETE FROM stories WHERE expiresAt < :currentTime")
    suspend fun deleteExpiredStories(currentTime: Long = System.currentTimeMillis())

    // Testing
    @Query("SELECT * FROM stories WHERE userId = :userId AND expiresAt > :currentTime ORDER BY createdAt DESC")
    fun getAllActiveStoriesByUser(userId: Int, currentTime: Long = System.currentTimeMillis()): Flow<List<Story>>
}