package com.ljcollege.momento.Database

import android.util.Log
import com.ljcollege.momento.Database.User.User
import com.ljcollege.momento.Database.User.UserDao
import com.ljcollege.momento.Database.Story.Story
import com.ljcollege.momento.Database.Story.StoryDao
import com.ljcollege.momento.Database.Post.Post
import com.ljcollege.momento.Database.Post.PostDao
import com.ljcollege.momento.Database.Post.Like
import com.ljcollege.momento.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object DummyDataInitializer {

    suspend fun populateDummyData(
        userDao: UserDao,
        storyDao: StoryDao,
        postDao: PostDao
    ) {
        withContext(Dispatchers.IO) {
            Log.d("DummyDataInitializer", "Starting to insert dummy users")

            // Users with all required fields (name, username, email, password) and optional fields
            val users = listOf(
                User(
                    name = "Joshua Smith",
                    username = "joshua_s",
                    email = "joshua@example.com",
                    password = "password123",
                    profilePic = "https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
                    bio = "Instagram lover"
                ),
                User(
                    name = "Karen Lee",
                    username = "karenne_k",
                    email = "karenne@example.com",
                    password = "123",
                    profilePic = "https://images.pexels.com/photos/771742/pexels-photo-771742.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
                    bio = "Story enthusiast"
                ),
                User(
                    name = "Zack Johnson",
                    username = "zackjohn_z",
                    email = "zackjohn@example.com",
                    password = "123",
                    profilePic = "https://images.pexels.com/photos/30056387/pexels-photo-30056387/free-photo-of-dramatic-light-on-marble-sculpture-of-a-face.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
                    bio = "Post addict"
                ),
                User(
                    name = "Lily Brown",
                    username = "lily_l",
                    email = "lily@example.com",
                    password = "123",
                    profilePic = "https://images.pexels.com/photos/10274665/pexels-photo-10274665.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
                    bio = "Photo lover"
                ),
                User(
                    name = "Mike Davis",
                    username = "mike_m",
                    email = "mike@example.com",
                    password = "123",
                    profilePic = "https://images.pexels.com/photos/30798466/pexels-photo-30798466/free-photo-of-moody-artistic-portrait-with-motion-blur.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
                    bio = "Video creator"
                )
            )
            users.forEach { userDao.insertUser(it) }

            // Fetch inserted users by username (Line 72 onwards)
            val insertedUsers = listOf(
                userDao.getUserByUsername("joshua_s"),
                userDao.getUserByUsername("karenne_k"),
                userDao.getUserByUsername("zackjohn_z"),
                userDao.getUserByUsername("lily_l"),
                userDao.getUserByUsername("mike_m")
            ).filterNotNull()

            if (insertedUsers.size != 5) {
                Log.e("DummyDataInitializer", "Failed to retrieve all inserted users")
                return@withContext
            }

            val userIdMap = insertedUsers.associate { it.username to it.id }

            // Stories (assuming Story.kt structure)
            val stories = listOf(
                Story(userId = userIdMap["joshua_s"]!!, mediaUrl = "https://images.pexels.com/photos/30798466/pexels-photo-30798466/free-photo-of-moody-artistic-portrait-with-motion-blur.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"),
                Story(userId = userIdMap["joshua_s"]!!, mediaUrl = "https://images.pexels.com/photos/30419561/pexels-photo-30419561/free-photo-of-snowy-night-street-scene-in-berlin.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"),
                Story(userId = userIdMap["karenne_k"]!!, mediaUrl = "https://images.pexels.com/photos/30335638/pexels-photo-30335638/free-photo-of-cozy-outdoor-cafe-with-sheepskin-chairs.jpeg?auto=compress&cs=tinysrgb&w=400&lazy=load"),
                Story(userId = userIdMap["karenne_k"]!!, mediaUrl = "https://images.pexels.com/photos/5412246/pexels-photo-5412246.jpeg?auto=compress&cs=tinysrgb&w=400"),
                Story(userId = userIdMap["zackjohn_z"]!!, mediaUrl = "https://images.pexels.com/photos/3907252/pexels-photo-3907252.jpeg?auto=compress&cs=tinysrgb&w=400"),
                Story(userId = userIdMap["zackjohn_z"]!!, mediaUrl = "https://images.pexels.com/photos/6920391/pexels-photo-6920391.jpeg?auto=compress&cs=tinysrgb&w=400"),
                Story(userId = userIdMap["lily_l"]!!, mediaUrl = "https://images.pexels.com/photos/2823459/pexels-photo-2823459.jpeg?auto=compress&cs=tinysrgb&w=400"),
                Story(userId = userIdMap["lily_l"]!!, mediaUrl = "https://videos.pexels.com/video-files/3571264/3571264-sd_640_360_30fps.mp4"),
                Story(userId = userIdMap["mike_m"]!!, mediaUrl = "https://videos.pexels.com/video-files/3327058/3327058-sd_640_360_24fps.mp4"),
                Story(userId = userIdMap["mike_m"]!!, mediaUrl = "https://images.pexels.com/photos/1151282/pexels-photo-1151282.jpeg?auto=compress&cs=tinysrgb&w=400")
            )
            stories.forEach { storyDao.insertStory(it) }

            // Posts matching Post.kt structure
            val posts = mutableListOf<Post>()
            val postData = listOf(
                Triple("joshua_s", "https://images.pexels.com/photos/1151282/pexels-photo-1151282.jpeg?auto=compress&cs=tinysrgb&w=400", "Enjoying the day!"),
                Triple("joshua_s", "https://videos.pexels.com/video-files/3327058/3327058-sd_640_360_24fps.mp4", "Cool video moment!"),
                Triple("karenne_k", "https://images.pexels.com/photos/3608263/pexels-photo-3608263.jpeg?auto=compress&cs=tinysrgb&w=400", "Sunny day vibes!"),
                Triple("karenne_k", "https://images.pexels.com/photos/164222/pexels-photo-164222.jpeg?auto=compress&cs=tinysrgb&w=400", "Fun at the beach!"),
                Triple("zackjohn_z", "https://videos.pexels.com/video-files/3571264/3571264-sd_640_360_30fps.mp4", "Chilling outdoors!"),
                Triple("zackjohn_z", "https://videos.pexels.com/video-files/30741489/13150272_360_640_60fps.mp4", "Epic skate session!"),
                Triple("lily_l", "https://videos.pexels.com/video-files/16657013/16657013-sd_360_640_24fps.mp4", "Beautiful sunset!"),
                Triple("lily_l", "https://images.pexels.com/photos/30056387/pexels-photo-30056387/free-photo-of-dramatic-light-on-marble-sculpture-of-a-face.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load", "Dance party time!"),
                Triple("mike_m", "https://images.pexels.com/photos/30835571/pexels-photo-30835571/free-photo-of-elegant-parisian-architecture-at-night.jpeg?auto=compress&cs=tinysrgb&w=400", "Mountain hike view!"),
                Triple("mike_m", "https://images.pexels.com/photos/164222/pexels-photo-164222.jpeg?auto=compress&cs=tinysrgb&w=400", "Adventure in the wild!")
            )
            postData.forEachIndexed { index, (username, mediaUrl, caption) ->
                posts.add(
                    Post(
                        id = index + 1, // Unique ID for each post
                        userId = userIdMap[username]!!,
                        location = listOf("New York", "Los Angeles", "Chicago", "Miami", "Seattle")[index / 2],
                        mediaUrl = mediaUrl,
                        likesCount = 0,
                        caption = caption,
                    )
                )
            }
            posts.forEach { postDao.insertPost(it) }

            // Likes
            val likes = listOf(
                Like(userId = userIdMap["karenne_k"]!!, postId = posts[0].id),
                Like(userId = userIdMap["zackjohn_z"]!!, postId = posts[0].id),
                Like(userId = userIdMap["lily_l"]!!, postId = posts[1].id),
                Like(userId = userIdMap["mike_m"]!!, postId = posts[2].id),
                Like(userId = userIdMap["joshua_s"]!!, postId = posts[4].id)
            )
            likes.forEach { postDao.insertLike(it) }
        }
    }
}