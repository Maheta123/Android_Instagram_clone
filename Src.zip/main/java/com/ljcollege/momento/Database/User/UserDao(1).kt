package com.ljcollege.momento.Database.User

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface UserDao {
    @Query("SELECT username FROM users WHERE id = :id")
    suspend fun getUsernameById(id: Int): String?

    @Update
    suspend fun updateUser(user: User)

    @Query("SELECT profilePic FROM users WHERE id = :id")
    suspend fun getProfilePicById(id: Int): String?

    @Insert
    suspend fun insertUser(user: User)

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?

    @Query("SELECT COUNT(*) > 0 FROM users WHERE username = :username")
    suspend fun usernameExists(username: String): Boolean

    // New method to fetch all users
    @Query("SELECT * FROM users")
    suspend fun getAllUsers(): List<User>



    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: String): User?


    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: Int): User?


    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun getUserLive(userId: Int): LiveData<User?>


}