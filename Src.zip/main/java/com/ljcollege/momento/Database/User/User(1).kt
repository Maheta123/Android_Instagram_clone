package com.ljcollege.momento.Database.User

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo

@Entity(tableName = "users", indices = [androidx.room.Index(value = ["username"], unique = true)])
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    var name: String = "",
    @ColumnInfo(name = "username") val username: String,
    val email: String,
    val password: String,
    var profilePic: String? = "",
    var bio: String? = "",
    val createdAt: Long = System.currentTimeMillis()
)