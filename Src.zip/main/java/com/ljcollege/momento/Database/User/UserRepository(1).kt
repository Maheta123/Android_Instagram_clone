package com.ljcollege.momento.Database.User

import android.util.Log

class UserRepository(private val userDao: UserDao) {
    suspend fun getUserByEmail(email: String): User? {
        return try {
            userDao.getUserByEmail(email)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error fetching user by email: ${e.message}")
            null
        }
    }

    suspend fun updateUser(user: User) {
        try {
            userDao.updateUser(user)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error updating user: ${e.message}")
        }
    }

    suspend fun getUserByUsername(username: String): User? {
        return try {
            userDao.getUserByUsername(username)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error fetching user by username: ${e.message}")
            null
        }
    }

    suspend fun getUsernameById(id: Int): String? {
        return userDao.getUsernameById(id)
    }

    suspend fun getProfilePicById(id: Int): String? {
        return userDao.getProfilePicById(id)
    }

    suspend fun insertUser(user: User) {
        try {
            userDao.insertUser(user)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error inserting user: ${e.message}")
        }
    }

    suspend fun isUsernameUnique(username: String): Boolean {
        return try {
            !userDao.usernameExists(username)
        } catch (e: Exception) {
            Log.e("UserRepository", "Error checking username uniqueness: ${e.message}")
            false
        }
    }

    // New method to fetch all users
    suspend fun getAllUsers(): List<User> {
        return try {
            userDao.getAllUsers()
        } catch (e: Exception) {
            Log.e("UserRepository", "Error fetching all users: ${e.message}")
            emptyList()
        }
    }


    suspend fun getUserById(userId: Int): User? {
        return userDao.getUserById(userId)
    }



}