package com.ljcollege.momento

import android.app.Application
import com.ljcollege.momento.Database.AppDatabase

class App : Application() {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(this) }
}