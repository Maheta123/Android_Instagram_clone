package com.ljcollege.momento.Model

data class PostUiModel(
    val id: Int,
    val userId: Int,
    val userAvatarRes: Int,
    val username: String,
    val location: String,
    val mediaUrl: String?,
    val likesCount: Int,
    val caption: String,
    val postedAgo: String,
    val isLikedByCurrentUser: Boolean
)
