package com.ljcollege.momento.Model

data class Post(
    val id: Int,
    val userId: Int,
    val username: String,
    val userAvatarRes: Int,
    val mediaUrl: String?,
    val caption: String,
    var likesCount: Int,
    val location: String?,
    val postedAgo: String,
    var isLikedByCurrentUser: Boolean = false
)