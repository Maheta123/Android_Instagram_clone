package com.ljcollege.momento.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import jakarta.mail.*
import jakarta.mail.internet.InternetAddress
import jakarta.mail.internet.MimeMessage
import java.util.*

object EmailSender {

    suspend fun sendOtp(recipientEmail: String, otpCode: String): String {
        return withContext(Dispatchers.IO) {
            try {
                val props = Properties().apply {
                    put("mail.smtp.host", "smtp.gmail.com")
                    put("mail.smtp.port", "587")
                    put("mail.smtp.auth", "true")
                    put("mail.smtp.starttls.enable", "true")
                }

                val session = Session.getInstance(props, object : Authenticator() {
                    override fun getPasswordAuthentication(): PasswordAuthentication {
                        return PasswordAuthentication(EMAIL_SENDER, EMAIL_PASSWORD)
                    }
                })

                val message = MimeMessage(session).apply {
                    setFrom(InternetAddress(EMAIL_SENDER))
                    addRecipient(Message.RecipientType.TO, InternetAddress(recipientEmail))
                    subject = "Your OTP Code"
                    setText("Your OTP code is $otpCode. It is valid for 5 minutes.")
                }

                Transport.send(message)
                "SUCCESS"
            } catch (e: AuthenticationFailedException) {
                "INVALID_CREDENTIALS"
            } catch (e: MessagingException) {
                "NETWORK_ERROR"
            } catch (e: Exception) {
                "FAILED"
            }
        }
    }

    private const val EMAIL_SENDER = "error400error@gmail.com"
    private const val EMAIL_PASSWORD = "legr ermo uktp qnwh"
}
