package com.ljcollege.momento

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ljcollege.momento.databinding.ActivityChatsBinding
import com.ljcollege.momento.databinding.ItemChatBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ChatsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityChatsBinding
    private lateinit var chatAdapter: ChatAdapter
    private var selectedChat: Chat? = null

    // Data class for individual messages
    data class Message(
        val content: String,
        val isSent: Boolean, // true for sent, false for received
        val timestamp: String
    )

    // Data class to represent a chat item
    data class Chat(
        val username: String,
        var lastMessage: String, // Made var to allow updates
        var timestamp: String, // Made var to allow updates
        val profilePicture: String?, // URL for online images
        val profilePictureResId: Int?, // Local drawable resource ID
        val messages: MutableList<Message> // Conversation history
    )

    // Sample chat variables (list of chats to be displayed)
    private val chatList = mutableListOf(
        Chat(
            username = "Alice Smith",
            lastMessage = "Sounds good!",
            timestamp = "10:30 AM",
            profilePicture = "https://images.pexels.com/photos/30798466/pexels-photo-30798466/free-photo-of-moody-artistic-portrait-with-motion-blur.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
            profilePictureResId = null,
            messages = mutableListOf(
                Message("Hey, how's it going?", false, "10:25 AM"),
                Message("Pretty good, you?", true, "10:28 AM"),
                Message("Just chilling!", false, "10:29 AM"),
                Message("Sounds good!", true, "10:30 AM")
            )
        ),
        Chat(
            username = "Bob Johnson",
            lastMessage = "Cool, see you then!",
            timestamp = "9:15 AM",
            profilePicture = "https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
            profilePictureResId = null,
            messages = mutableListOf(
                Message("Can we meet tomorrow?", false, "9:10 AM"),
                Message("Sure, what time?", true, "9:12 AM"),
                Message("How about 10 AM?", false, "9:14 AM"),
                Message("Cool, see you then!", true, "9:15 AM")
            )
        ),
        Chat(
            username = "Emma Davis",
            lastMessage = "You're welcome!",
            timestamp = "Yesterday",
            profilePicture = "https://images.pexels.com/photos/30798466/pexels-photo-30798466/free-photo-of-moody-artistic-portrait-with-motion-blur.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
            profilePictureResId = R.drawable.ic_profile_placeholder,
            messages = mutableListOf(
                Message("Thanks for the update!", false, "Yesterday"),
                Message("You're welcome!", true, "Yesterday")
            )
        ),
        Chat(
            username = "Michael Brown",
            lastMessage = "Awesome!",
            timestamp = "Monday",
            profilePicture = null,
            profilePictureResId = R.drawable.ic_profile_placeholder,
            messages = mutableListOf(
                Message("See you at the event!", false, "Monday"),
                Message("Awesome!", true, "Monday")
            )
        ),
        Chat(
            username = "Sarah Wilson",
            lastMessage = "Looks amazing!",
            timestamp = "8:45 AM",
            profilePicture = null,
            profilePictureResId = R.drawable.ic_profile_placeholder,
            messages = mutableListOf(
                Message("Check out this new place!", false, "8:40 AM"),
                Message("Looks amazing!", true, "8:45 AM")
            )
        ),
        Chat(
            username = "James Lee",
            lastMessage = "No problem!",
            timestamp = "7:30 PM",
            profilePicture = null,
            profilePictureResId = R.drawable.ic_profile_placeholder,
            messages = mutableListOf(
                Message("Got the files, thanks!", false, "7:25 PM"),
                Message("No problem!", true, "7:30 PM")
            )
        ),
        Chat(
            username = "Olivia Clark",
            lastMessage = "Can’t wait!",
            timestamp = "Tuesday",
            profilePicture = null,
            profilePictureResId = R.drawable.ic_profile_placeholder,
            messages = mutableListOf(
                Message("Let’s plan the trip soon.", false, "Tuesday"),
                Message("Can’t wait!", true, "Tuesday")
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener {
            if (binding.chatView.visibility == View.VISIBLE) {
                showChatList()
            } else {
                onBackPressedDispatcher.onBackPressed()
            }
        }

        // Initialize adapter with the full chat list
        chatAdapter = ChatAdapter(chatList) { chat ->
            // On chat item click, show single chat view
            selectedChat = chat
            showSingleChat(chat)
        }
        binding.chatRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.chatRecyclerView.adapter = chatAdapter

        // Set up search functionality
        binding.searchBar.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s.toString().trim().lowercase()
                filterChats(query)
            }
        })

        // Set up back button for single chat view
        binding.chatBackButton.setOnClickListener {
            showChatList()
        }

        // Set up send button for replies
        binding.sendButton.setOnClickListener {
            val messageText = binding.messageInput.text.toString().trim()
            if (messageText.isNotEmpty() && selectedChat != null) {
                val timestamp = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                val newMessage = Message(messageText, true, timestamp)
                Log.d("ChatsActivity", "Sending message: $messageText, Chat: ${selectedChat?.username}")
                val messageAdapter = binding.messageRecyclerView.adapter as? MessageAdapter
                messageAdapter?.addMessage(newMessage) // Add to adapter (which also adds to selectedChat.messages)
                selectedChat?.lastMessage = messageText
                selectedChat?.timestamp = timestamp
                chatAdapter.notifyDataSetChanged() // Update chat list to reflect new last message
                binding.messageInput.text.clear()
                // Scroll to the latest message
                binding.messageRecyclerView.scrollToPosition(selectedChat!!.messages.size - 1)
                Log.d("ChatsActivity", "Messages after send: ${selectedChat?.messages}")
            } else {
                Log.e("ChatsActivity", "Cannot send message: Empty text or no selected chat")
            }
        }

        // Show chat list by default
        showChatList()
    }

    // Filter chats based on search query
    private fun filterChats(query: String) {
        val filteredList = if (query.isEmpty()) {
            chatList // Show all chats if query is empty
        } else {
            chatList.filter {
                it.username.lowercase().contains(query) ||
                        it.lastMessage.lowercase().contains(query)
            }
        }
        chatAdapter.updateList(filteredList)
    }

    // Show the chat list view
    private fun showChatList() {
        binding.chatListView.visibility = View.VISIBLE
        binding.chatView.visibility = View.GONE
        supportActionBar?.title = "Chats"
        selectedChat = null
        binding.searchBar.text.clear() // Clear search when returning to list
    }

    // Show the single chat view
    private fun showSingleChat(chat: Chat) {
        binding.chatListView.visibility = View.GONE
        binding.chatView.visibility = View.VISIBLE
        supportActionBar?.title = chat.username
        binding.chatUsername.text = chat.username
        // Load profile picture
        if (chat.profilePicture != null) {
            Glide.with(binding.chatProfilePicture.context)
                .load(chat.profilePicture)
                .placeholder(R.drawable.ic_profile_placeholder)
                .error(R.drawable.ic_profile_placeholder)
                .into(binding.chatProfilePicture)
        } else if (chat.profilePictureResId != null) {
            binding.chatProfilePicture.setImageResource(chat.profilePictureResId)
        }
        // Set up message RecyclerView
        val layoutManager = LinearLayoutManager(this)
        layoutManager.stackFromEnd = true
        binding.messageRecyclerView.layoutManager = layoutManager
        binding.messageRecyclerView.adapter = MessageAdapter(chat.messages)
        binding.messageRecyclerView.scrollToPosition(chat.messages.size - 1)
        Log.d("ChatsActivity", "Showing chat for ${chat.username}, Messages: ${chat.messages}")
    }

    // Handle toolbar navigation (back button) click
    override fun onSupportNavigateUp(): Boolean {
        if (binding.chatView.visibility == View.VISIBLE) {
            showChatList()
            return true
        }
        onBackPressedDispatcher.onBackPressed()
        return true
    }

    // RecyclerView Adapter for chat list
    private class ChatAdapter(
        private val chats: MutableList<Chat>,
        private val onChatClick: (Chat) -> Unit
    ) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

        // ViewHolder for each chat item
        class ChatViewHolder(
            private val binding: ItemChatBinding,
            private val onChatClick: (Chat) -> Unit
        ) : RecyclerView.ViewHolder(binding.root) {
            fun bind(chat: Chat) {
                binding.username.text = chat.username
                binding.lastMessage.text = chat.lastMessage
                binding.timestamp.text = chat.timestamp
                // Load profile picture: URL with Glide or local resource
                if (chat.profilePicture != null) {
                    Glide.with(binding.profilePicture.context)
                        .load(chat.profilePicture)
                        .placeholder(R.drawable.ic_profile_placeholder)
                        .error(R.drawable.ic_profile_placeholder)
                        .into(binding.profilePicture)
                } else if (chat.profilePictureResId != null) {
                    binding.profilePicture.setImageResource(chat.profilePictureResId)
                }
                // Set click listener for the item
                binding.root.setOnClickListener { onChatClick(chat) }
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
            val binding = ItemChatBinding.inflate(
                LayoutInflater.from(parent.context), parent, false
            )
            return ChatViewHolder(binding, onChatClick)
        }

        override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
            holder.bind(chats[position])
        }

        override fun getItemCount(): Int = chats.size

        // Update the list and notify adapter of changes
        fun updateList(newList: List<Chat>) {
            chats.clear()
            chats.addAll(newList)
            notifyDataSetChanged()
        }
    }

    // RecyclerView Adapter for messages in single chat view
    private class MessageAdapter(
        private val messages: MutableList<Message>
    ) : RecyclerView.Adapter<MessageAdapter.MessageViewHolder>() {

        companion object {
            const val VIEW_TYPE_SENT = 1
            const val VIEW_TYPE_RECEIVED = 2
        }

        // ViewHolder for each message
        class MessageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            private val messageText: TextView = itemView.findViewById(R.id.message_text)
            private val timestampText: TextView = itemView.findViewById(R.id.message_timestamp)

            fun bind(message: Message) {
                messageText.text = message.content
                timestampText.text = message.timestamp
            }
        }

        override fun getItemViewType(position: Int): Int {
            return if (messages[position].isSent) VIEW_TYPE_SENT else VIEW_TYPE_RECEIVED
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageViewHolder {
            val layoutId = if (viewType == VIEW_TYPE_SENT) {
                R.layout.item_message_sent
            } else {
                R.layout.item_message_received
            }
            val view = LayoutInflater.from(parent.context).inflate(layoutId, parent, false)
            return MessageViewHolder(view)
        }

        override fun onBindViewHolder(holder: MessageViewHolder, position: Int) {
            holder.bind(messages[position])
        }

        override fun getItemCount(): Int = messages.size

        // Add a single message and notify adapter
        fun addMessage(newMessage: Message) {
            // Ensure message is not already in the list
            if (!messages.contains(newMessage)) {
                messages.add(newMessage)
                notifyItemInserted(messages.size - 1)
                Log.d("MessageAdapter", "Added message: ${newMessage.content}, Total messages: ${messages.size}")
            } else {
                Log.w("MessageAdapter", "Message already exists: ${newMessage.content}")
            }
        }
    }
}