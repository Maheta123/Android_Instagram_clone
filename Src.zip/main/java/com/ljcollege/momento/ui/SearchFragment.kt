package com.ljcollege.momento.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.User.User
import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import coil.load

class SearchFragment : Fragment() {

    private lateinit var searchEditText: EditText
    private lateinit var searchButton: Button
    private lateinit var userRecyclerView: RecyclerView
    private lateinit var userAdapter: UserAdapter
    private lateinit var userRepository: UserRepository
    private var allUsers: List<User> = emptyList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_search, container, false)

        searchEditText = view.findViewById(R.id.searchEditText)
        searchButton = view.findViewById(R.id.searchButton)
        userRecyclerView = view.findViewById(R.id.userRecyclerView)

        userRepository = UserRepository(AppDatabase.getDatabase(requireContext()).userDao())

        userAdapter = UserAdapter(emptyList()) { user, isFollowing ->
            // Handle follow/unfollow click (for now, just toggle in-memory)
            toggleFollowStatus(user, isFollowing)
        }
        userRecyclerView.layoutManager = LinearLayoutManager(context)
        userRecyclerView.adapter = userAdapter

        loadAllUsers()

        searchButton.setOnClickListener {
            val query = searchEditText.text.toString().trim()
            filterUsers(query)
        }

        return view
    }

    private fun loadAllUsers() {
        CoroutineScope(Dispatchers.IO).launch {
            allUsers = userRepository.getAllUsers()
            withContext(Dispatchers.Main) {
                userAdapter.updateUsers(allUsers)
            }
        }
    }

    private fun filterUsers(query: String) {
        CoroutineScope(Dispatchers.Main).launch {
            if (query.isEmpty()) {
                userAdapter.updateUsers(allUsers)
            } else {
                val filteredUsers = allUsers.filter { user ->
                    user.username.contains(query, ignoreCase = true)
                }
                userAdapter.updateUsers(filteredUsers)
            }
        }
    }

    private fun toggleFollowStatus(user: User, isFollowing: Boolean) {
        // For now, just log the action; later, update a database or backend
        val action = if (isFollowing) "Unfollowed" else "Followed"
        println("$action user: ${user.username}") // Replace with actual logic
    }
}

class UserAdapter(
    private var users: List<User>,
    private val onFollowClick: (User, Boolean) -> Unit
) : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

    // Map to track follow status (in-memory for now)
    private val followStatusMap = mutableMapOf<Int, Boolean>()

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val profileImageView: ImageView = itemView.findViewById(R.id.profileImageView)
        val usernameTextView: TextView = itemView.findViewById(R.id.usernameTextView)
        val followButton: Button = itemView.findViewById(R.id.followButton)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_user, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val user = users[position]

        // Load profile picture (using Coil)
        holder.profileImageView.load(user.profilePic ?: "") {
            placeholder(R.drawable.ic_profile_placeholder) // Add a placeholder drawable
            error(R.drawable.ic_profile_placeholder) // Add an error drawable
        }

        holder.usernameTextView.text = user.username

        // Set follow/unfollow button state
        val isFollowing = followStatusMap[user.id] ?: false
        holder.followButton.text = if (isFollowing) "Unfollow" else "Follow"
        holder.followButton.setOnClickListener {
            followStatusMap[user.id] = !isFollowing
            onFollowClick(user, isFollowing)
            notifyItemChanged(position) // Update button text
        }
    }

    override fun getItemCount(): Int = users.size

    fun updateUsers(newUsers: List<User>) {
        users = newUsers
        notifyDataSetChanged()
    }
}