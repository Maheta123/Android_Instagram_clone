package com.ljcollege.momento.ui

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.MediaController
import android.widget.VideoView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.Post.PostRepository
import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.Model.Post as UiPost
import com.ljcollege.momento.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ReelsFragment : Fragment() {

    private lateinit var reelsRecyclerView: RecyclerView
    private lateinit var postRepository: PostRepository
    private lateinit var userRepository: UserRepository
    private val posts = mutableListOf<UiPost>() // List to hold video posts
    private lateinit var reelsAdapter: ReelsAdapter // Use the proper adapter class

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_reels, container, false)

        // Initialize repositories
        userRepository = UserRepository(AppDatabase.getDatabase(requireContext()).userDao())
        postRepository = PostRepository(AppDatabase.getDatabase(requireContext()).postDao(), userRepository)

        // Setup RecyclerView
        reelsRecyclerView = view.findViewById(R.id.reelsRecyclerView)
        reelsRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Initialize the adapter
        reelsAdapter = ReelsAdapter(posts)
        reelsRecyclerView.adapter = reelsAdapter

        // Load video posts
        loadVideoPosts()

        return view
    }

    private fun loadVideoPosts() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                postRepository.getAllPosts().collectLatest { uiPosts ->
                    // Filter for videos based on .mp4 extension and ensure mediaUrl is not null
                    val videoPosts = uiPosts.filter { post ->
                        post.mediaUrl?.endsWith(".mp4", ignoreCase = true) == true
                    }
                    Log.d("ReelsFragment", "Fetched ${videoPosts.size} video posts")
                    reelsAdapter.updatePosts(videoPosts)
                }
            } catch (e: Exception) {
                Log.e("ReelsFragment", "Error loading video posts: ${e.message}")
                reelsAdapter.updatePosts(emptyList())
            }
        }
    }

    // Inner adapter class to properly handle view holder and updates
    inner class ReelsAdapter(private var posts: List<UiPost>) : RecyclerView.Adapter<ReelViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReelViewHolder {
            val itemView = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_reel, parent, false)
            return ReelViewHolder(itemView)
        }

        override fun onBindViewHolder(holder: ReelViewHolder, position: Int) {
            val post = posts[position]

            // Safely handle nullable mediaUrl
            post.mediaUrl?.let { url ->
                if (url.endsWith(".mp4", ignoreCase = true)) {
                    holder.videoView.setVideoPath(url)
                    val mediaController = MediaController(holder.videoView.context)
                    mediaController.setAnchorView(holder.videoView)
                    holder.videoView.setMediaController(mediaController)

                    holder.videoView.setOnPreparedListener { mp ->
                        mp.start()
                        mp.isLooping = true // Loop the reel
                    }

                    holder.videoView.setOnErrorListener { mp, what, extra ->
                        Log.e("ReelsFragment", "Error playing video at $url: what=$what, extra=$extra")
                        true
                    }
                } else {
                    Log.w("ReelsFragment", "Invalid video URL: $url")
                }
            } ?: run {
                Log.e("ReelsFragment", "Media URL is null for post at position $position")
            }
        }

        override fun getItemCount(): Int = posts.size

        fun updatePosts(newPosts: List<UiPost>) {
            // Calculate the difference between old and new posts
            val diff = newPosts.size - posts.size

            // Update the data
            posts = newPosts

            // Notify adapter based on the change
            if (diff > 0) {
                // New items added
                notifyItemRangeInserted(posts.size - diff, diff)
            } else if (diff < 0) {
                // Items removed
                notifyItemRangeRemoved(posts.size, -diff)
            } else {
                // Same size but content might have changed
                notifyItemRangeChanged(0, posts.size)
            }
        }
    }

    inner class ReelViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val videoView: VideoView = itemView.findViewById(R.id.reelVideoView)
    }
}