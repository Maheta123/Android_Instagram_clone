package com.ljcollege.momento.ui

import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.Post.Post
import com.ljcollege.momento.R
import com.ljcollege.momento.ui.auth.LoginPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AddPostActivity : AppCompatActivity() {

    private lateinit var editTextCaption: EditText
    private lateinit var editTextLocation: EditText
    private lateinit var buttonSubmitPost: Button
    private lateinit var imageViewSelectedMedia: ImageView
    private var userId: Int = -1
    private var mediaUri: Uri? = null

    private val postDao by lazy {
        AppDatabase.getDatabase(this).postDao()
    }

    private val pickImageRequestCode = 1001 // Request code to open gallery

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_post)

        // Initialize views
        editTextCaption = findViewById(R.id.editTextPostCaption)
        editTextLocation = findViewById(R.id.editTextPostLocation)
        buttonSubmitPost = findViewById(R.id.buttonSubmitPost)
        imageViewSelectedMedia = findViewById(R.id.imageViewSelectedMedia)

        // Retrieve the logged-in user ID from preferences
        userId = LoginPrefs.getUserId(this)?.toIntOrNull() ?: -1

        // Handle submit button click
        buttonSubmitPost.setOnClickListener {
            val caption = editTextCaption.text.toString().trim()
            val location = editTextLocation.text.toString().trim()

            if (mediaUri != null && caption.isNotEmpty()) {
                // Create a post object
                val post = Post(
                    userId = userId,
                    mediaUrl = mediaUri.toString(),  // Save media URI as a string
                    caption = caption,
                    location = location
                )

                // Save the post to the database
                savePostToDatabase(post)
            } else {
                Toast.makeText(this, "Please select media and enter caption", Toast.LENGTH_SHORT).show()
            }
        }

        // Setup toolbar
        val toolbar = findViewById<androidx.appcompat.widget.Toolbar>(R.id.toolbarAddPost)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_back)

        // Launch gallery to pick media
        openGalleryForImage()
    }

    private fun openGalleryForImage() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, pickImageRequestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK && requestCode == pickImageRequestCode) {
            // Retrieve selected media URI
            mediaUri = data?.data
            mediaUri?.let {
                imageViewSelectedMedia.setImageURI(it)  // Display the selected image in ImageView
            }
        }
    }

    private fun savePostToDatabase(post: Post) {
        lifecycleScope.launch(Dispatchers.IO) {
            // Insert the post into the database
            postDao.insertPost(post)

            withContext(Dispatchers.Main) {
                Toast.makeText(this@AddPostActivity, "Post added successfully", Toast.LENGTH_SHORT).show()
                finish()  // Close the activity and return to the previous screen
            }
        }
    }
}
