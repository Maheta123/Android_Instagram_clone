package com.ljcollege.momento.ui

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.Post.Post
import com.ljcollege.momento.Database.Post.PostDao
import com.ljcollege.momento.Database.User.UserDao
import com.ljcollege.momento.R
import com.ljcollege.momento.ui.auth.LoginActivity
import com.ljcollege.momento.ui.auth.LoginPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.app.AlertDialog

class ProfileFragment : Fragment() {

    private lateinit var imageViewProfilePic: ImageView
    private lateinit var textViewUsername: TextView
    private lateinit var textViewBio: TextView
    private lateinit var textViewPostsCount: TextView
    private lateinit var recyclerViewPosts: RecyclerView
    private lateinit var btnLogout: Button
    private lateinit var buttonEditProfile: ImageButton

    private lateinit var userDao: UserDao
    private lateinit var postDao: PostDao
    private var currentUserId: Int = -1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view = inflater.inflate(R.layout.profile_fragment, container, false)

        // Toolbar setup
        val toolbar = view.findViewById<androidx.appcompat.widget.Toolbar>(R.id.profileToolbar)
        (requireActivity() as? AppCompatActivity)?.apply {
            setSupportActionBar(toolbar)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
        }

        // Initialize UI elements
        imageViewProfilePic = view.findViewById(R.id.imageViewProfilePic)
        textViewUsername = view.findViewById(R.id.textViewUsername)
        textViewBio = view.findViewById(R.id.textViewBio)
        textViewPostsCount = view.findViewById(R.id.textViewPostsCount)
        recyclerViewPosts = view.findViewById(R.id.recyclerViewPosts)
        buttonEditProfile = view.findViewById(R.id.buttonEditProfile)

        recyclerViewPosts.layoutManager = GridLayoutManager(requireContext(), 3)

        // Initialize DAOs
        val db = AppDatabase.getDatabase(requireContext())
        userDao = db.userDao()
        postDao = db.postDao()

        // Set listeners
        buttonEditProfile.setOnClickListener { openEditProfile() }

        // Observe user and their posts
        val userIdString = LoginPrefs.getUserId(requireContext())
        userIdString?.toIntOrNull()?.let {
            observeUserLiveData(it)
            observeUserPosts(it)
        }

        return view
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.profile_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_add_post -> {
                // Handle Add Post action
                startActivity(Intent(requireContext(), AddPostActivity::class.java))
                true
            }
            R.id.action_logout -> {
                // Handle Logout action
                logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        loadUserData()
    }

    private fun openEditProfile() {
        val intent = Intent(requireContext(), EditProfileActivity::class.java)
        intent.putExtra("USER_ID", currentUserId)
        startActivity(intent)
    }

    private fun observeUserLiveData(userId: Int) {
        userDao.getUserLive(userId).observe(viewLifecycleOwner) { user ->
            user?.let {
                currentUserId = it.id
                textViewUsername.text = it.name
                textViewBio.text = it.bio ?: "No bio yet"

                Glide.with(requireContext())
                    .load(it.profilePic)
                    .circleCrop()
                    .placeholder(R.drawable.ic_default_profile_pic)
                    .into(imageViewProfilePic)

                showUserPostsCount(it.id)
            }
        }
    }

    private fun loadUserData() {
        val userIdString = LoginPrefs.getUserId(requireContext())

        if (!userIdString.isNullOrEmpty()) {
            lifecycleScope.launch(Dispatchers.IO) {
                val user = userDao.getUserById(userIdString.toInt())
                withContext(Dispatchers.Main) {
                    user?.let { u ->
                        currentUserId = u.id
                        textViewUsername.text = u.name
                        textViewBio.text = u.bio ?: "No bio yet"

                        Glide.with(requireContext())
                            .load(u.profilePic)
                            .circleCrop()
                            .placeholder(R.drawable.ic_default_profile_pic)
                            .into(imageViewProfilePic)

                        showUserPostsCount(u.id)
                        observeUserPosts(u.id)
                    }
                }
            }
        }
    }

    private fun showUserPostsCount(userId: Int) {
        lifecycleScope.launch(Dispatchers.IO) {
            val userPostsCount = postDao.getUserPostCount(userId)
            withContext(Dispatchers.Main) {
                textViewPostsCount.text = "Posts: $userPostsCount"
            }
        }
    }

    private fun observeUserPosts(userId: Int) {
        lifecycleScope.launch {
            postDao.getPostsByUser(userId).collectLatest { posts ->
                val postAdapter = PostAdapter(posts) { post ->
                    // Show the Edit/Delete options when a post is clicked
                    showPostOptionsDialog(post)
                }
                recyclerViewPosts.adapter = postAdapter
            }
        }
    }

    private fun showPostOptionsDialog(post: Post) {
        val options = arrayOf("Edit Post", "Delete Post")

        AlertDialog.Builder(requireContext())
            .setTitle("Post Options")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> editPost(post) // Edit post
                    1 -> deletePost(post) // Delete post
                }
            }
            .show()
    }

    private fun editPost(post: Post) {
        val intent = Intent(requireContext(), EditPostActivity::class.java)
        intent.putExtra("POST_ID", post.id)  // Pass post ID to the edit screen
        startActivity(intent)
    }

    private fun deletePost(post: Post) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Post")
            .setMessage("Are you sure you want to delete this post?")
            .setPositiveButton("Yes") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    postDao.delete(post)
                    withContext(Dispatchers.Main) {
                        // Refresh the posts after deletion
                        observeUserPosts(currentUserId)
                    }
                }
            }
            .setNegativeButton("No", null)
            .show()
    }

    private fun logout() {
        LoginPrefs.clearLogin(requireContext())
        val intent = Intent(requireContext(), LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        requireActivity().finish()
    }
}
