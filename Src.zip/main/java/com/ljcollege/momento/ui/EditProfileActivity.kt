package com.ljcollege.momento.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.User.UserDao
import com.ljcollege.momento.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditProfileActivity : AppCompatActivity() {
    private lateinit var userDao: UserDao
    private lateinit var imageViewProfilePic: ImageView
    private lateinit var editTextUsername: EditText
    private lateinit var editTextBio: EditText
    private lateinit var buttonSaveProfile: Button
    private lateinit var buttonChangeProfilePic: Button

    private var currentUserId: Int = -1
    private var currentProfileUri: Uri? = null

    companion object {
        const val PICK_IMAGE_REQUEST = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        // Initialize views
        imageViewProfilePic = findViewById(R.id.imageViewProfilePic)
        editTextUsername = findViewById(R.id.editTextUsername)
        editTextBio = findViewById(R.id.editTextBio)
        buttonSaveProfile = findViewById(R.id.buttonSaveProfile)
        buttonChangeProfilePic = findViewById(R.id.buttonChangeProfilePic)

        // Get user ID from the intent (passed from ProfileFragment)
        currentUserId = intent.getIntExtra("USER_ID", -1)

        // Initialize the DAO
        val db = AppDatabase.getDatabase(this)
        userDao = db.userDao()

        // Load user data asynchronously
        loadUserData()

        // Set listeners
        buttonSaveProfile.setOnClickListener { saveProfile() }
        buttonChangeProfilePic.setOnClickListener { changeProfilePicture() }
    }

    private fun loadUserData() {
        // Fetch user data asynchronously using a coroutine
        lifecycleScope.launch(Dispatchers.IO) {
            val user = userDao.getUserById(currentUserId.toString()) // Fetch user from DB
            withContext(Dispatchers.Main) {
                user?.let {
                    editTextUsername.setText(it.username)
                    editTextBio.setText(it.bio)

                    // Load profile picture if exists
                    Glide.with(this@EditProfileActivity)
                        .load(it.profilePic)
                        .circleCrop()
                        .placeholder(R.drawable.ic_default_profile_pic)
                        .into(imageViewProfilePic)
                }
            }
        }
    }

    private fun saveProfile() {
        val username = editTextUsername.text.toString()
        val bio = editTextBio.text.toString()

        if (username.isNotEmpty()) {
            // Save changes in the database asynchronously
            lifecycleScope.launch(Dispatchers.IO) {
                // Fetch the current user from the database
                val user = userDao.getUserById(currentUserId.toString())
                user?.let {
                    // Update user object with new data
                    it.name = username
                    it.bio = bio
                    it.profilePic = currentProfileUri.toString() // Save the new URI for the profile photo

                    // Update the user in the database
                    userDao.updateUser(it) // Use `updateUser()` method from UserDao
                }

                // Inform the UI on the main thread
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@EditProfileActivity, "Profile updated successfully", Toast.LENGTH_SHORT).show()
                    finish() // Close the activity and return to ProfileFragment
                }
            }
        } else {
            Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show()
        }
    }

    private fun changeProfilePicture() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            currentProfileUri = data.data
            Glide.with(this)
                .load(currentProfileUri)
                .circleCrop()
                .into(imageViewProfilePic)
        }
    }
}
