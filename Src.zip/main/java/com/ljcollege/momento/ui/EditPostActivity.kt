package com.ljcollege.momento.ui

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.Post.Post
import com.ljcollege.momento.Database.Post.PostDao
import com.ljcollege.momento.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class EditPostActivity : AppCompatActivity() {

    private lateinit var imageViewPostImage: ImageView
    private lateinit var editTextCaption: EditText
    private lateinit var editTextLocation: EditText
    private lateinit var buttonSaveChanges: Button

    private lateinit var postDao: PostDao
    private var postId: Int = -1
    private var originalPost: Post? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_post)

        // Initialize UI elements
        imageViewPostImage = findViewById(R.id.imageViewPostImage)
        editTextCaption = findViewById(R.id.editTextCaption)
        editTextLocation = findViewById(R.id.editTextLocation)
        buttonSaveChanges = findViewById(R.id.buttonSaveChanges)

        // Initialize Post DAO
        val db = AppDatabase.getDatabase(this)
        postDao = db.postDao()

        // Get the post ID passed through Intent
        postId = intent.getIntExtra("POST_ID", -1)
        if (postId != -1) {
            loadPostData(postId)
        }

        buttonSaveChanges.setOnClickListener {
            savePostChanges()
        }
    }

    private fun loadPostData(postId: Int) {
        lifecycleScope.launch(Dispatchers.IO) {
            val post = postDao.getPostById(postId)
            withContext(Dispatchers.Main) {
                post?.let {
                    originalPost = it
                    editTextCaption.setText(it.caption)
                    editTextLocation.setText(it.location)

                    Glide.with(this@EditPostActivity)
                        .load(it.mediaUrl)
                        .centerCrop()
                        .placeholder(R.drawable.ic_launcher_background)
                        .into(imageViewPostImage)
                }
            }
        }
    }

    private fun savePostChanges() {
        val newCaption = editTextCaption.text.toString()
        val newLocation = editTextLocation.text.toString()

        originalPost?.let { post ->
            if (newCaption != post.caption || newLocation != post.location) {
                val updatedPost = post.copy(
                    caption = newCaption,
                    location = newLocation
                )

                lifecycleScope.launch(Dispatchers.IO) {
                    postDao.update(updatedPost)
                    withContext(Dispatchers.Main) {
                        finish()
                    }
                }
            }
        }
    }
}
