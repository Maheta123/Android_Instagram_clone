package com.ljcollege.momento.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ljcollege.momento.Database.Post.Post
import com.ljcollege.momento.R

class PostAdapter(
    private val posts: List<Post>,
    private val onPostClick: (Post) -> Unit // Callback for handling post click
) : RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.post_item_profile, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]

        // Set the image (media) - assuming it's an image URL or resource ID
        Glide.with(holder.itemView.context)
            .load(post.mediaUrl)
            .centerCrop()
            .placeholder(R.drawable.ic_launcher_background)
            .into(holder.imageViewPostMedia)

        // Set the caption
        holder.textViewPostCaption.text = post.caption ?: "No caption available"

        // Set the location if available
        if (post.location.isNullOrEmpty()) {
            holder.textViewPostLocation.visibility = View.GONE
        } else {
            holder.textViewPostLocation.visibility = View.VISIBLE
            holder.textViewPostLocation.text = post.location
        }

        // Set the likes count
        holder.textViewLikesCount.text = "${post.likesCount} Likes"

        // Set click listener to trigger the callback (show Edit/Delete options)
        holder.itemView.setOnClickListener {
            onPostClick(post)
        }
    }

    override fun getItemCount(): Int {
        return posts.size
    }

    inner class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageViewPostMedia: ImageView = view.findViewById(R.id.imageViewPostMedia)
        val textViewPostCaption: TextView = view.findViewById(R.id.textViewPostCaption)
        val textViewPostLocation: TextView = view.findViewById(R.id.textViewPostLocation)
        val textViewLikesCount: TextView = view.findViewById(R.id.textViewLikesCount)
    }
}
