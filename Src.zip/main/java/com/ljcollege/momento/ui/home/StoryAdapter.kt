    package com.ljcollege.momento.ui.home

    import android.content.Context
    import android.view.LayoutInflater
    import android.view.ViewGroup
    import androidx.recyclerview.widget.RecyclerView
    import com.bumptech.glide.Glide
    import com.ljcollege.momento.Model.Post as UiPost
    import com.ljcollege.momento.R
    import com.ljcollege.momento.databinding.StoryItemBinding
    import android.util.Log

    class StoryAdapter(private var stories: List<UiPost>, private val context: Context) : RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
            val binding = StoryItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return StoryViewHolder(binding)
        }

        override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
            try {
                holder.bind(stories[position])
            } catch (e: Exception) {
                Log.e("StoryAdapter", "Error binding story at position $position: ${e.message}")
            }
        }

        override fun getItemCount(): Int = stories.size

        class StoryViewHolder(private val binding: StoryItemBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(story: UiPost) {
                try {
                    // Bind username
                    binding.storyUsername.text = story.username ?: "Unknown"
                    // Bind avatar using Glide with fallback
                    Glide.with(binding.root.context)
                        .load(story.userAvatarRes) // Use userAvatarRes as a drawable resource or URL
                        .placeholder(R.drawable.ic_user_placeholder) // Fallback image if load fails
                        .error(R.drawable.ic_user_placeholder) // Error image if load fails
                        .centerCrop()
                        .into(binding.storyAvatar)
                } catch (e: Exception) {
                    Log.e("StoryViewHolder", "Error binding story: ${e.message}")
                    binding.storyUsername.text = "Unknown"
                    Glide.with(binding.root.context)
                        .load(R.drawable.ic_user_placeholder)
                        .centerCrop()
                        .into(binding.storyAvatar)
                }
            }
        }

        fun updateData(newStories: List<UiPost>) {
            stories = newStories
            notifyDataSetChanged()
        }
    }