package com.ljcollege.momento.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.Database.Story.StoryRepository
import com.ljcollege.momento.Database.Post.PostRepository
import com.ljcollege.momento.Model.Post as UiPost
import com.ljcollege.momento.R
import com.ljcollege.momento.databinding.FragmentHomeBinding
import com.ljcollege.momento.ui.auth.LoginPrefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import android.util.Log



class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val userRepository: UserRepository by lazy {
        UserRepository(AppDatabase.getDatabase(requireContext()).userDao())
    }
    private val storyRepository: StoryRepository by lazy {
        StoryRepository(AppDatabase.getDatabase(requireContext()).storyDao())
    }
    private val postRepository: PostRepository by lazy {
        PostRepository(AppDatabase.getDatabase(requireContext()).postDao(), userRepository)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Set up RecyclerView for stories (horizontal)
        binding.storyRecyclerView.layoutManager = LinearLayoutManager(
            requireContext(),
            LinearLayoutManager.HORIZONTAL,
            false
        )
        binding.storyRecyclerView.adapter = StoryAdapter(emptyList(), requireContext())

        // Set up RecyclerView for posts (vertical, scrollable)
        binding.feedRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        val postAdapter = PostAdapter(mutableListOf(), requireContext()) // Initialize adapter
        binding.feedRecyclerView.adapter = postAdapter

        // Load all stories for the current user (horizontal display)
        val currentUserIdString = LoginPrefs.getUserId(requireContext())
        val currentUserId = currentUserIdString?.toIntOrNull()
        if (currentUserId != null) {
            CoroutineScope(Dispatchers.Main).launch {
                try {
                    storyRepository.getAllActiveStoriesByUser(currentUserId).collectLatest { dbStories ->
                        Log.d("HomeFragment", "Fetched ${dbStories.size} stories for user $currentUserId")
                        val uiStories = dbStories.map { story ->
                            UiPost(
                                id = story.id,
                                userId = story.userId,
                                userAvatarRes = R.drawable.ic_user_placeholder,
                                username = userRepository.getUsernameById(story.userId) ?: "Unknown",
                                location = "",
                                mediaUrl = story.mediaUrl,
                                likesCount = 0,
                                caption = "",
                                postedAgo = formatTimeAgo(story.createdAt),
                                isLikedByCurrentUser = false // Match your Post model
                            )
                        }
                        Log.d("HomeFragment", "Mapped ${uiStories.size} UI stories")
                        (binding.storyRecyclerView.adapter as? StoryAdapter)?.updateData(uiStories)
                    }
                } catch (e: Exception) {
                    Log.e("HomeFragment", "Error loading stories: ${e.message}")
                    (binding.storyRecyclerView.adapter as? StoryAdapter)?.updateData(emptyList())
                }
            }
        } else {
            Log.e("HomeFragment", "Invalid or missing user ID: $currentUserIdString")
            (binding.storyRecyclerView.adapter as? StoryAdapter)?.updateData(emptyList())
        }

        // Load all posts for all users (vertical, scrollable display)
        CoroutineScope(Dispatchers.Main).launch {
            try {
                postRepository.getAllPosts().collectLatest { uiPosts ->
                    Log.d("HomeFragment", "Fetched ${uiPosts.size} posts")
                    postAdapter.updatePosts(uiPosts) // Use updated method
                }
            } catch (e: Exception) {
                Log.e("HomeFragment", "Error loading posts: ${e.message}")
                postAdapter.updatePosts(emptyList())
            }
        }
    }

    private fun formatTimeAgo(timestamp: Long): String {
        val now = System.currentTimeMillis()
        val diff = now - timestamp
        val minutes = diff / (1000 * 60)
        return when {
            minutes < 1 -> "Just now"
            minutes < 60 -> "$minutes minutes ago"
            minutes < 1440 -> "${minutes / 60} hours ago"
            else -> "${minutes / 1440} days ago"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}