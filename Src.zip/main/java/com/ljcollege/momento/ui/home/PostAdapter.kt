package com.ljcollege.momento.ui.home

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ljcollege.momento.Model.Post
import com.ljcollege.momento.R







class PostAdapter(private val posts: MutableList<Post>, private val context: Context) :
    RecyclerView.Adapter<PostAdapter.PostViewHolder>() {

    inner class PostViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val userAvatar: ImageView = view.findViewById(R.id.userAvatar)
        val userNickName: TextView = view.findViewById(R.id.userNickName)
        val feedImage: ImageView = view.findViewById(R.id.feedImage)
        val likeIcon: ImageView = view.findViewById(R.id.likeIcon)
        val tvLikes: TextView = view.findViewById(R.id.tvLikes)
        val postedAgo: TextView = view.findViewById(R.id.postedAgo)
        val commentIcon: ImageView = view.findViewById(R.id.commentIcon)
        val shareIcon: ImageView = view.findViewById(R.id.shareIcon)

        var isLiked = false
        var likeCount = 0



        private fun toggleLike() {
            isLiked = !isLiked
            likeCount += if (isLiked) 1 else -1
            posts[adapterPosition].isLikedByCurrentUser = isLiked
            posts[adapterPosition].likesCount = likeCount

            likeIcon.setImageResource(
                if (isLiked) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
            )
            likeIcon.setColorFilter(
                if (isLiked) context.getColor(R.color.red) else context.getColor(R.color.white)
            )
            animateLikeButton()
            updateLikeText()
            notifyItemChanged(adapterPosition)
        }

        private fun animateLikeButton() {
            val scaleAnimation = ScaleAnimation(
                1f, 1.2f, 1f, 1.2f,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
            )
            scaleAnimation.duration = 200
            scaleAnimation.repeatMode = Animation.REVERSE
            likeIcon.startAnimation(scaleAnimation)
        }

        private fun updateLikeText() {
            tvLikes.text = if (isLiked) "Liked by You and $likeCount others"
            else "Liked by $likeCount people"
        }

        private fun sharePost(mediaUrl: String?) {
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Check this out: $mediaUrl")
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share via"))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.feed_item, parent, false)
        return PostViewHolder(view)
    }

    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post = posts[position]
        holder.userNickName.text = post.username
        holder.postedAgo.text = post.postedAgo
        holder.tvLikes.text = "Liked by ${post.likesCount} people"
        Glide.with(context)
            .load(post.userAvatarRes)
            .circleCrop()
            .into(holder.userAvatar)

        Glide.with(context).load(post.mediaUrl).into(holder.feedImage)
        holder.isLiked = post.isLikedByCurrentUser
        holder.likeCount = post.likesCount
        holder.likeIcon.setImageResource(
            if (post.isLikedByCurrentUser) R.drawable.ic_heart_filled else R.drawable.ic_heart_outline
        )
        holder.likeIcon.setColorFilter(
            if (post.isLikedByCurrentUser) context.getColor(R.color.red) else context.getColor(R.color.white)
        )
    }

    override fun getItemCount() = posts.size

    // Added method to update posts dynamically
    fun updatePosts(newPosts: List<Post>) {
        posts.clear()
        posts.addAll(newPosts)
        notifyDataSetChanged()
    }
}
