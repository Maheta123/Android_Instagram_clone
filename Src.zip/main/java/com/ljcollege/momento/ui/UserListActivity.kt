package com.ljcollege.momento.ui

class UserListActivity {
}