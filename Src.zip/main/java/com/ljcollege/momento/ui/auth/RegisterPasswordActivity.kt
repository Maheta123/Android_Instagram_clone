package com.ljcollege.momento.ui.auth

import android.content.Intent
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ljcollege.momento.R
import com.ljcollege.momento.databinding.ActivityRegisterPasswordBinding

class RegisterPasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterPasswordBinding
    private lateinit var username: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        username = intent.getStringExtra("username") ?: ""

        binding.backButton.setOnClickListener {
            finish()
        }

        binding.btnNext.setOnClickListener {
            val password = binding.inputPassword.text.toString().trim()
            if (isValidPassword(password)) {
                val intent = Intent(this, RegisterEmailOtpActivity::class.java)
                intent.putExtra("username", username)
                intent.putExtra("password", password)
                startActivity(intent)
            } else {
                binding.passwordErrorText.text = "Password must be 8+ characters with uppercase, number, and special character"
                binding.passwordErrorText.visibility = View.VISIBLE
            }
        }

        binding.togglePasswordVisibility.setOnCheckedChangeListener { _, isChecked ->
            binding.inputPassword.transformationMethod =
                if (isChecked) null else PasswordTransformationMethod.getInstance()
            binding.inputPassword.text?.let { binding.inputPassword.setSelection(it.length) }
        }
    }

    private fun isValidPassword(password: String): Boolean =
        password.length >= 8 && password.any { it.isUpperCase() } &&
                password.any { it.isDigit() } && password.any { !it.isLetterOrDigit() }

    private fun showError(message: String) = Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
}