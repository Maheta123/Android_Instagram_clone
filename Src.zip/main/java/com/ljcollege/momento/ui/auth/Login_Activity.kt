package com.ljcollege.momento.ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.MainActivity
import com.ljcollege.momento.R
import com.ljcollege.momento.databinding.ActivityLoginBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var userRepository: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userRepository = UserRepository(AppDatabase.getDatabase(this).userDao())

        if (LoginPrefs.isLoggedIn(this)) {
            navigateToHome()
            return
        }

        binding.loginButton.setOnClickListener {
            val identifier = binding.emailOrUsernameEditText.text.toString().trim()
            val password = binding.passwordEditText.text.toString().trim()
            if (identifier.isNotEmpty() && password.isNotEmpty()) {
                loginUser(identifier, password)
            } else {
                binding.errorTextView.text = "Please enter both identifier and password"
                binding.errorTextView.visibility = View.VISIBLE
            }
        }

        binding.signUpTextView.setOnClickListener {
            startActivity(Intent(this, RegisterUsernameActivity::class.java))
        }

        binding.forgotPassword.setOnClickListener {
            startActivity(Intent(this, ResetPasswordActivity::class.java))
        }
    }

    private fun navigateToHome() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            putExtra("SHOW_HOME_FRAGMENT", true)
        })
        finish()
    }

    private fun loginUser(identifier: String, password: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val isEmail = identifier.contains("@")
                var user = if (isEmail) userRepository.getUserByEmail(identifier)
                else userRepository.getUserByUsername(identifier)

                if (user == null) {
                    user = if (isEmail) userRepository.getUserByUsername(identifier)
                    else userRepository.getUserByEmail(identifier)
                }

                withContext(Dispatchers.Main) {
                    if (user != null && user.password == password) {
                        LoginPrefs.saveLogin(this@LoginActivity, user.id.toString()) // Int to String
                        navigateToHome()
                    } else {
                        binding.errorTextView.text = "Invalid identifier or password"
                        binding.errorTextView.visibility = View.VISIBLE
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.errorTextView.text = "An error occurred. Please try again."
                    binding.errorTextView.visibility = View.VISIBLE
                    Log.e("LoginActivity", "Login error: ${e.message}")
                }
            }
        }
    }
}