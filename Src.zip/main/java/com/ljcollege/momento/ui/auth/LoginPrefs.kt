package com.ljcollege.momento.ui.auth

import android.content.Context
import android.content.SharedPreferences

object LoginPrefs {
    private const val PREF_NAME = "UserPrefs"
    private const val KEY_USER_ID = "userId"
    private const val KEY_IS_LOGGED_IN = "isLoggedIn"

    fun getSharedPreferences(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    fun saveLogin(context: Context, userId: String) {
        val prefs = getSharedPreferences(context)
        prefs.edit().apply {
            putString(KEY_USER_ID, userId)
            putBoolean(KEY_IS_LOGGED_IN, true)
            apply()
        }
    }

    fun clearLogin(context: Context) {
        val prefs = getSharedPreferences(context)
        prefs.edit().clear().apply()
    }

    fun isLoggedIn(context: Context): Boolean {
        val prefs = getSharedPreferences(context)
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun getUserId(context: Context): String? {
        val prefs = getSharedPreferences(context)
        return prefs.getString(KEY_USER_ID, null)
    }
}