package com.ljcollege.momento.ui.auth

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.text.method.PasswordTransformationMethod
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ljcollege.momento.R
import com.ljcollege.momento.databinding.ActivityResetPasswordBinding
import com.ljcollege.momento.utils.EmailSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

class ResetPasswordActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResetPasswordBinding
    private var generatedOtp = ""
    private var isOtpSent = false
    private var countDownTimer: CountDownTimer? = null
    private var email = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityResetPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSendOtp.setOnClickListener {
            email = binding.inputEmail.text.toString().trim()
            if (email.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch { sendOtp(email) }
            } else {
                binding.inputEmail.error = "Enter a valid email"
            }
        }

        binding.btnVerifyOtp.setOnClickListener {
            val otp = binding.inputOtp.text.toString().trim()
            if (otp == generatedOtp && isOtpSent) {
                binding.emailVerificationStep.visibility = View.GONE
                binding.setPasswordStep.visibility = View.VISIBLE
                binding.emailTextView.text = "Reset password for: $email"
            } else {
                binding.inputOtp.error = "Incorrect OTP or OTP not sent"
            }
        }

        binding.btnResetPassword.setOnClickListener {
            val newPassword = binding.inputNewPassword.text.toString().trim()
            if (isValidPassword(newPassword)) {
                resetPassword(email, newPassword)
            } else {
                binding.inputNewPassword.error = "Password must be 8+ characters with uppercase, number, and special character"
            }
        }

        binding.togglePasswordVisibility.setOnCheckedChangeListener { _, isChecked ->
            binding.inputNewPassword.transformationMethod =
                if (isChecked) null else PasswordTransformationMethod.getInstance()
            binding.inputNewPassword.text?.let { binding.inputNewPassword.setSelection(it.length) }
        }
    }

    private fun isValidPassword(password: String): Boolean =
        password.length >= 8 && password.any { it.isUpperCase() } &&
                password.any { it.isDigit() } && password.any { !it.isLetterOrDigit() }

    private suspend fun sendOtp(email: String) {
        generatedOtp = Random.nextInt(100000, 999999).toString()
        val result = EmailSender.sendOtp(email, generatedOtp)
        withContext(Dispatchers.Main) {
            when (result) {
                "SUCCESS" -> {
                    isOtpSent = true
                    showSuccess("OTP sent to $email")
                    startOtpTimer()
                    binding.btnVerifyOtp.isEnabled = true
                    binding.inputOtp.isEnabled = true
                }
                "INVALID_CREDENTIALS" -> showError("Invalid email credentials. Contact support.")
                "NETWORK_ERROR" -> showError("Network error. Check your connection and try again.")
                "FAILED" -> showError("Failed to send OTP. Try again later.")
            }
        }
    }

    private fun startOtpTimer() {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(60000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.otpTimerText.text = "Resend OTP in ${millisUntilFinished / 1000} sec"
            }

            override fun onFinish() {
                isOtpSent = false
                binding.otpTimerText.text = "Resend OTP"
                binding.btnVerifyOtp.isEnabled = false
                binding.inputOtp.isEnabled = false
                binding.otpTimerText.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch { sendOtp(email) }
                }
            }
        }.start()
    }

    private fun resetPassword(email: String, newPassword: String) {
        // TODO: Add actual database update logic here
        showSuccess("Password reset successfully!")
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }

    private fun showSuccess(message: String) = Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
    private fun showError(message: String) = Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}