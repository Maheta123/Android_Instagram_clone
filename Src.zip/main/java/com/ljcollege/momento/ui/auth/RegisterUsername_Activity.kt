package com.ljcollege.momento.ui.auth

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.R
import com.ljcollege.momento.databinding.ActivityRegisterUsernameBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class RegisterUsernameActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterUsernameBinding
    private lateinit var userRepository: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterUsernameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userRepository = UserRepository(AppDatabase.getDatabase(this).userDao())

        binding.btnNext.isEnabled = false

        binding.backButton.setOnClickListener {
            finish()
        }

        binding.inputUsername.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val username = s.toString().trim()
                if (username.isNotEmpty()) {
                    checkUsernameAvailability(username)
                } else {
                    binding.usernameUnderline.setBackgroundResource(R.drawable.line_gray)
                    binding.btnNext.isEnabled = false
                    binding.usernameStatus.text = "Username cannot be empty"
                    binding.usernameStatus.setTextColor(resources.getColor(android.R.color.darker_gray))
                }
            }
        })

        binding.btnNext.setOnClickListener {
            val username = binding.inputUsername.text.toString().trim()
            val intent = Intent(this, RegisterPasswordActivity::class.java)
            intent.putExtra("username", username)
            startActivity(intent)
        }
    }

    private fun checkUsernameAvailability(username: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Show loading state
                withContext(Dispatchers.Main) {
                    binding.loadingUsername.visibility = View.VISIBLE
                    binding.usernameStatus.text = "Checking..."
                    binding.usernameStatus.setTextColor(resources.getColor(android.R.color.darker_gray))
                }

                val isUnique = userRepository.isUsernameUnique(username) // Line 63 (fixed)

                withContext(Dispatchers.Main) {
                    binding.loadingUsername.visibility = View.GONE
                    if (isUnique) {
                        binding.usernameUnderline.setBackgroundResource(R.drawable.line_green)
                        binding.btnNext.isEnabled = true
                        binding.usernameStatus.text = "Username available"
                        binding.usernameStatus.setTextColor(resources.getColor(android.R.color.holo_green_dark))
                    } else {
                        binding.usernameUnderline.setBackgroundResource(R.drawable.line_red)
                        binding.btnNext.isEnabled = false
                        binding.usernameStatus.text = "Username taken"
                        binding.usernameStatus.setTextColor(resources.getColor(android.R.color.holo_red_dark))
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.loadingUsername.visibility = View.GONE
                    binding.usernameUnderline.setBackgroundResource(R.drawable.line_red)
                    binding.btnNext.isEnabled = false
                    binding.usernameStatus.text = "Error checking username"
                    binding.usernameStatus.setTextColor(resources.getColor(android.R.color.holo_red_dark))
                }
            }
        }
    }
}