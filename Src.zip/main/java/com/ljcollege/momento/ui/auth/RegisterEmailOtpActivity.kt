package com.ljcollege.momento.ui.auth

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ljcollege.momento.Database.AppDatabase
import com.ljcollege.momento.Database.User.User
import com.ljcollege.momento.Database.User.UserRepository
import com.ljcollege.momento.MainActivity
import com.ljcollege.momento.R
import com.ljcollege.momento.databinding.ActivityRegisterEmailOtpBinding
import com.ljcollege.momento.utils.EmailSender
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.random.Random

class RegisterEmailOtpActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegisterEmailOtpBinding
    private lateinit var userRepository: UserRepository
    private var generatedOtp = ""
    private var isOtpSent = false
    private var countDownTimer: CountDownTimer? = null
    private lateinit var username: String
    private lateinit var password: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterEmailOtpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        userRepository = UserRepository(AppDatabase.getDatabase(this).userDao())
        username = intent.getStringExtra("username") ?: ""
        password = intent.getStringExtra("password") ?: ""

        binding.backButton.setOnClickListener {
            finish()
        }

        binding.btnSendOtp.setOnClickListener {
            val email = binding.inputEmail.text.toString().trim()
            if (email.isNotEmpty()) {
                CoroutineScope(Dispatchers.IO).launch { sendOtp(email) }
            } else {
                binding.inputEmail.error = "Enter a valid email"
            }
        }

        binding.btnVerifyOtp.setOnClickListener {
            val otp = binding.inputOtp.text.toString().trim()
            if (otp == generatedOtp && isOtpSent) {
                val email = binding.inputEmail.text.toString().trim()
                registerUser(username, password, email)
            } else {
                binding.inputOtp.error = "Incorrect OTP"
            }
        }
    }

    private suspend fun sendOtp(email: String) {
        generatedOtp = Random.nextInt(100000, 999999).toString()
        val result = EmailSender.sendOtp(email, generatedOtp)
        withContext(Dispatchers.Main) {
            when (result) {
                "SUCCESS" -> {
                    isOtpSent = true
                    showSuccess("OTP sent to $email")
                    startOtpTimer()
                    binding.btnVerifyOtp.isEnabled = true
                    binding.inputOtp.isEnabled = true
                }
                "INVALID_CREDENTIALS" -> showError("Invalid email credentials. Contact support.")
                "NETWORK_ERROR" -> showError("Network error. Check your connection and try again.")
                "FAILED" -> showError("Failed to send OTP. Try again later.")
            }
        }
    }

    private fun startOtpTimer() {
        countDownTimer?.cancel()
        countDownTimer = object : CountDownTimer(60000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.otpTimerText.text = "Resend OTP in ${millisUntilFinished / 1000} sec"
            }

            override fun onFinish() {
                isOtpSent = false
                binding.otpTimerText.text = "Resend OTP"
                binding.btnVerifyOtp.isEnabled = false
                binding.inputOtp.isEnabled = false
                binding.otpTimerText.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch { sendOtp(binding.inputEmail.text.toString().trim()) }
                }
            }
        }.start()
    }

    private fun registerUser(username: String, password: String, email: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Add default name since it's required; could prompt user for this earlier
                val user = User(
                    name = username, // Using username as default name; adjust as needed
                    username = username,
                    password = password,
                    email = email
                )
                userRepository.insertUser(user)

                // Retrieve the inserted user to get the auto-generated id
                val insertedUser = userRepository.getUserByUsername(username)
                if (insertedUser != null) {
                    withContext(Dispatchers.Main) {
                        LoginPrefs.saveLogin(this@RegisterEmailOtpActivity, insertedUser.id.toString())
                        showSuccess("Registration successful!")
                        startActivity(Intent(this@RegisterEmailOtpActivity, MainActivity::class.java))
                        finishAffinity()
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        showError("Failed to retrieve registered user")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showError("Registration failed: ${e.message}")
                }
            }
        }
    }

    private fun showSuccess(message: String) = Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
    private fun showError(message: String) = Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}