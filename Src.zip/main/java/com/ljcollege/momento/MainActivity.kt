package com.ljcollege.momento

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.ljcollege.momento.databinding.ActivityMainBinding
import com.ljcollege.momento.ui.ProfileFragment
import com.ljcollege.momento.ui.ReelsFragment
import com.ljcollege.momento.ui.SearchFragment
import com.ljcollege.momento.ui.auth.LoginActivity
import com.ljcollege.momento.ui.auth.LoginPrefs
import com.ljcollege.momento.ui.home.HomeFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (!LoginPrefs.isLoggedIn(this)) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        // Messenger icon click listener
        binding.messengerIcon.setOnClickListener {
            val intent = Intent(this, ChatsActivity::class.java)
            startActivity(intent)
        }

        bottomNavigationView = binding.bottomNavigation
        updateBottomNavigationMenu()
        setupBottomNavigation()

        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
        }
    }

    private fun updateBottomNavigationMenu() {
        bottomNavigationView.menu.clear()
        bottomNavigationView.inflateMenu(R.menu.bottom_nav_menu)
        bottomNavigationView.visibility = View.VISIBLE
    }

    private fun setupBottomNavigation() {
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.Home -> {
                    loadFragment(HomeFragment())
                    true
                }
                R.id.Reels -> {
                    loadFragment(ReelsFragment())
                    true
                }
                R.id.Search -> {
                    loadFragment(SearchFragment())
                    true
                }
                R.id.Profile -> {
                    loadFragment(ProfileFragment())
                    true
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    private fun logout() {
        Log.d("MainActivity", "Clearing SharedPreferences and navigating to LoginActivity")
        val PREF_NAME = "UserPrefs"
        val sharedPrefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE)
        val editor = sharedPrefs.edit()
        editor.clear()
        editor.apply()
        startActivity(Intent(this, LoginActivity::class.java))
        finish()
    }
}